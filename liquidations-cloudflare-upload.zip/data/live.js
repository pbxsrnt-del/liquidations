/* Placeholder. On the live site _worker.js answers /data/live.js with the
   edits made on the phone editor (admin.html). Do not edit. */
window.LIQ_LIVE = window.LIQ_LIVE || {};
